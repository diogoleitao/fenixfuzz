export JAVA_OPTS="-server -Xms256m -Xmx1024m -XX:PermSize=384m"
export MAVEN_OPTS="-Djava.awt.headless=true -Xms1g -Xmx2g -XX:+UseG1GC -XX:+UseStringDeduplication -Dorg.apache.jasper.compiler.Parser.STRICT_QUOTE_ESCAPING=false -verbose:gc"
echo "Setting up the tunnel and connecting..."
ssh -A -fNg -L 10000:localhost:3306 mysqluser@fenix64bit.ist.utl.pt
mysql -hlocalhost --protocol=TCP -P10000 -uist169644 -pYmFlYzQwNzJhMDRhOGY2Y2Fh ist169644_fenix -A
echo "Done."
