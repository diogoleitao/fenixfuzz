mysql -uroot < bootstrap.sql
echo "MySQL bootstrap done."
