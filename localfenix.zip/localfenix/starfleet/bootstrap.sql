drop database starfleet;
create database starfleet;
use starfleet;
source clean.sql;
